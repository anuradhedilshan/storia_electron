import Proxylist from "./index";
const proxylist = new Proxylist();
proxylist.getProxy();
