import Logger_View from "./Logger_view";

export default Logger_View;
